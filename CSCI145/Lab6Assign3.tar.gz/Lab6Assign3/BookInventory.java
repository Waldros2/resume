import java.util.ArrayList;
import java.util.Scanner;
import java.io.*;

class BookInventory {

}