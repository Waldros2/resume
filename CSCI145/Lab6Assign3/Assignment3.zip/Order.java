class Order {

   String customerID;
   int quantity;
   
   Order(String customerID, int quantity) {
      this.quantity = quantity;
      this.customerID = customerID;
   }



}