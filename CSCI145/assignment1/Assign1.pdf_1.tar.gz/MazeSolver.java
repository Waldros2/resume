import java.util.Arrays;
import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;

public class MazeSolver {

   // The name of the file describing the maze
   static String mazefile;

   public static void main(String[] args) throws FileNotFoundException {
      if (handleArguments(args)) {
      
         readMazeFile(mazefile);
         char[][] maze = new char[3][];
         maze[0] = new char[]{'+','-','+'};
         maze[1] = new char[]{'|','S','|'};
         maze[2] = new char[]{'+','-','+'};
         DrawMaze.draw(1,1, maze);
      
         if (solveMaze())
            System.out.println("Solved!");
         else
            System.out.println("Maze has no solution.");
      }
   }
   
   // Handle the input arguments
   static boolean handleArguments(String[] args) {
      return true;
   }
   
   // Read the file describing the maze.
   static void readMazeFile(String mazefile) throws FileNotFoundException {
   }

   // Solve the maze.      
   static boolean solveMaze() {
      return true;
   }
}
